"use client"

import { useState } from "react"
import {
  BarChart,
  Bell,
  Calendar,
  ChevronDown,
  Clock,
  FileText,
  Home,
  Menu,
  Search,
  Settings,
  TrendingUp,
} from "lucide-react"
import Link from "next/link"

// Add type definitions at the top of the file, after the imports
// Define types for financial data structure
type FinancialMetric = {
  metric: string
  q2_2023: string
  q1_2023: string
  q4_2022: string
  q3_2022: string
  yoy: string
}

type EmitenFinancialData = {
  overview: FinancialMetric[]
  income: FinancialMetric[]
  balance: FinancialMetric[]
  cashflow: FinancialMetric[]
}

type FinancialDataType = {
  [key: string]: EmitenFinancialData
}

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function LaporanKeuanganPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedEmiten, setSelectedEmiten] = useState("BBCA")
  const [selectedPeriod, setSelectedPeriod] = useState("q2_2023")

  // Replace the existing emitenList with simpler static data
  const emitenList = [
    { code: "BBCA", name: "Bank Central Asia Tbk", sector: "Keuangan" },
    { code: "BBRI", name: "Bank Rakyat Indonesia Tbk", sector: "Keuangan" },
    { code: "TLKM", name: "Telkom Indonesia Tbk", sector: "Telekomunikasi" }
  ]

  // Replace the existing financialData with simpler static data
  const financialData: FinancialDataType = {
    BBCA: {
      overview: [
        {
          metric: "Pendapatan",
          q2_2023: "Rp 25.7T",
          q1_2023: "Rp 24.2T",
          q4_2022: "Rp 23.8T",
          q3_2022: "Rp 23.1T",
          yoy: "+6.2%",
        },
        {
          metric: "Laba Bersih",
          q2_2023: "Rp 10.5T",
          q1_2023: "Rp 9.8T", 
          q4_2022: "Rp 9.5T",
          q3_2022: "Rp 9.2T",
          yoy: "+7.1%",
        },
        {
          metric: "ROE",
          q2_2023: "19.8%",
          q1_2023: "19.2%",
          q4_2022: "18.9%", 
          q3_2022: "18.5%",
          yoy: "+0.6%",
        }
      ],
      income: [
        {
          metric: "Pendapatan Bunga",
          q2_2023: "Rp 18.2T",
          q1_2023: "Rp 17.5T",
          q4_2022: "Rp 17.2T",
          q3_2022: "Rp 16.8T",
          yoy: "+4.0%",
        }
      ],
      balance: [
        {
          metric: "Total Aset",
          q2_2023: "Rp 1,350T",
          q1_2023: "Rp 1,320T",
          q4_2022: "Rp 1,300T",
          q3_2022: "Rp 1,280T",
          yoy: "+2.3%", 
        }
      ],
      cashflow: [
        {
          metric: "Arus Kas Operasi",
          q2_2023: "Rp 15.2T",
          q1_2023: "Rp 14.3T",
          q4_2022: "Rp 14.0T",
          q3_2022: "Rp 13.8T",
          yoy: "+6.3%",
        }
      ]
    }
  }

  // Filter emiten list based on search query
  const filteredEmitens = emitenList.filter((emiten) => {
    if (!searchQuery.trim()) return true

    const searchLower = searchQuery.toLowerCase()
    return (
      emiten.code.toLowerCase().includes(searchLower) ||
      emiten.name.toLowerCase().includes(searchLower) ||
      emiten.sector.toLowerCase().includes(searchLower)
    )
  })

  // Get financial data for selected emiten and period
  const getFinancialData = (emiten: string, section: string): FinancialMetric[] => {
    if (!financialData[emiten]) {
      return []
    }
    return financialData[emiten][section as keyof EmitenFinancialData] || []
  }

  const handleEmitenSelect = (code: string): void => {
    setSelectedEmiten(code)
  }

  const handlePeriodChange = (value: string): void => {
    setSelectedPeriod(value)
  }

  return (
    <div className="flex min-h-screen bg-[#0f172a]">
      {/* Sidebar */}
      <div className="hidden w-64 flex-col border-r border-[#1e293b] bg-[#0f172a] md:flex">
        <div className="flex h-16 items-center border-b border-[#1e293b] px-6">
          <Link href="/dashboard" className="flex items-center gap-2 text-lg font-semibold text-white">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-indigo-500 to-purple-600 text-white">
              <TrendingUp className="h-5 w-5" />
            </div>
            <span className="font-bold">FinanceHub</span>
          </Link>
        </div>
        <div className="flex-1 overflow-auto px-3 py-4">
          <div className="mb-6 px-3">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
              <Input
                type="search"
                placeholder="Cari emiten..."
                className="w-full border-[#1e293b] bg-[#1e293b] pl-8 text-slate-300 shadow-none placeholder:text-slate-500 focus-visible:ring-1 focus-visible:ring-indigo-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          <div className="space-y-1 px-3 py-2">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">Menu Utama</p>
            <Button variant="ghost" className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white">
              <Home className="mr-2 h-4 w-4" />
              <Link href="/dashboard">Dashboard</Link>
            </Button>
            <Button
              variant="ghost"
              className="w-full justify-start bg-[#1e293b] text-white hover:bg-[#2d3c52] hover:text-white"
            >
              <BarChart className="mr-2 h-4 w-4" />
              Laporan Keuangan
            </Button>
            <Button variant="ghost" className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white">
              <FileText className="mr-2 h-4 w-4" />
              <Link href="/berita">Berita</Link>
            </Button>
          </div>
          <div className="mt-6 space-y-1 px-3 py-2">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">Emiten Populer</p>
            {filteredEmitens.map((emiten) => (
              <Button
                key={emiten.code}
                variant="ghost"
                className={`w-full justify-start ${
                  selectedEmiten === emiten.code
                    ? "bg-[#1e293b] text-white"
                    : "text-slate-400 hover:bg-[#1e293b] hover:text-white"
                }`}
                onClick={() => handleEmitenSelect(emiten.code)}
              >
                <div
                  className={`mr-2 flex h-4 w-4 items-center justify-center rounded ${
                    emiten.code === "BBCA"
                      ? "bg-blue-500"
                      : emiten.code === "BBRI"
                        ? "bg-red-500"
                        : emiten.code === "TLKM"
                          ? "bg-green-500"
                          : emiten.code === "ASII"
                            ? "bg-purple-500"
                            : "bg-amber-500"
                  } text-[10px] font-bold text-white`}
                >
                  {emiten.code.charAt(0)}
                </div>
                {emiten.code} - {emiten.name}
              </Button>
            ))}
          </div>
        </div>
        <div className="border-t border-[#1e293b] p-4">
          <div className="flex items-center justify-between">
            <div className="text-xs text-slate-400">
              <Clock className="mr-1 inline-block h-3.5 w-3.5" />
              <span>Update: 15:30 WIB</span>
            </div>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-white">
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1">
        <header className="sticky top-0 z-10 flex h-16 items-center justify-between border-b border-[#1e293b] bg-[#0f172a]/80 px-4 backdrop-blur-sm md:px-6">
          <div className="flex items-center gap-4">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5 text-slate-400" />
                  <span className="sr-only">Toggle Menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-72 border-r border-[#1e293b] bg-[#0f172a] p-0">
                <div className="flex h-16 items-center border-b border-[#1e293b] px-6">
                  <Link href="/dashboard" className="flex items-center gap-2 text-lg font-semibold text-white">
                    <div className="flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-indigo-500 to-purple-600 text-white">
                      <TrendingUp className="h-5 w-5" />
                    </div>
                    <span className="font-bold">FinanceHub</span>
                  </Link>
                </div>
                <div className="px-3 py-4">
                  <div className="mb-6 px-3">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
                      <Input
                        type="search"
                        placeholder="Cari emiten..."
                        className="w-full border-[#1e293b] bg-[#1e293b] pl-8 text-slate-300 shadow-none placeholder:text-slate-500 focus-visible:ring-1 focus-visible:ring-indigo-500"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="space-y-1 px-3 py-2">
                    <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">Menu Utama</p>
                    <Button
                      variant="ghost"
                      className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white"
                    >
                      <Home className="mr-2 h-4 w-4" />
                      <Link href="/dashboard">Dashboard</Link>
                    </Button>
                    <Button
                      variant="ghost"
                      className="w-full justify-start bg-[#1e293b] text-white hover:bg-[#2d3c52] hover:text-white"
                    >
                      <BarChart className="mr-2 h-4 w-4" />
                      Laporan Keuangan
                    </Button>
                    <Button
                      variant="ghost"
                      className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white"
                    >
                      <FileText className="mr-2 h-4 w-4" />
                      <Link href="/berita">Berita</Link>
                    </Button>
                  </div>
                  <div className="mt-6 space-y-1 px-3 py-2">
                    <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">Emiten Populer</p>
                    {filteredEmitens.map((emiten) => (
                      <Button
                        key={emiten.code}
                        variant="ghost"
                        className={`w-full justify-start ${
                          selectedEmiten === emiten.code
                            ? "bg-[#1e293b] text-white"
                            : "text-slate-400 hover:bg-[#1e293b] hover:text-white"
                        }`}
                        onClick={() => handleEmitenSelect(emiten.code)}
                      >
                        <div
                          className={`mr-2 flex h-4 w-4 items-center justify-center rounded ${
                            emiten.code === "BBCA"
                              ? "bg-blue-500"
                              : emiten.code === "BBRI"
                                ? "bg-red-500"
                                : emiten.code === "TLKM"
                                  ? "bg-green-500"
                                  : emiten.code === "ASII"
                                    ? "bg-purple-500"
                                    : "bg-amber-500"
                          } text-[10px] font-bold text-white`}
                        >
                          {emiten.code.charAt(0)}
                        </div>
                        {emiten.code} - {emiten.name}
                      </Button>
                    ))}
                  </div>
                </div>
              </SheetContent>
            </Sheet>
            <h1 className="text-xl font-semibold text-white">Laporan Keuangan</h1>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden items-center gap-1 rounded-full bg-indigo-900/50 px-3 py-1 text-sm text-indigo-300 md:flex">
              <Clock className="h-3.5 w-3.5" />
              <span>Update: 15:30 WIB</span>
            </div>
            <Select defaultValue={selectedPeriod} onValueChange={handlePeriodChange}>
              <SelectTrigger className="w-[150px] border-[#1e293b] bg-[#1e293b] text-slate-300">
                <SelectValue placeholder="Pilih Periode" />
              </SelectTrigger>
              <SelectContent className="border-[#1e293b] bg-[#0f172a] text-slate-300">
                <SelectItem value="q2_2023">Q2 2023</SelectItem>
                <SelectItem value="q1_2023">Q1 2023</SelectItem>
                <SelectItem value="q4_2022">Q4 2022</SelectItem>
                <SelectItem value="q3_2022">Q3 2022</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
              <Bell className="h-4 w-4" />
              <span className="sr-only">Notifikasi</span>
            </Button>
          </div>
        </header>

        <div className="p-4 md:p-6">
          {/* Emiten Info */}
          <Card className="mb-6 overflow-hidden border-[#1e293b] bg-[#0f172a] shadow-lg">
            <CardHeader className="border-b border-[#1e293b] px-6">
              <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <div
                      className={`flex h-10 w-10 items-center justify-center rounded-md ${
                        selectedEmiten === "BBCA"
                          ? "bg-blue-900/50 text-blue-300"
                          : selectedEmiten === "BBRI"
                            ? "bg-red-900/50 text-red-300"
                            : selectedEmiten === "TLKM"
                              ? "bg-green-900/50 text-green-300"
                              : selectedEmiten === "ASII"
                                ? "bg-purple-900/50 text-purple-300"
                                : "bg-amber-900/50 text-amber-300"
                      }`}
                    >
                      <span className="text-lg font-bold">{selectedEmiten.charAt(0)}</span>
                    </div>
                    <CardTitle className="text-xl text-white">
                      {selectedEmiten} - {emitenList.find((e) => e.code === selectedEmiten)?.name || ""}
                    </CardTitle>
                    <div className="rounded-full bg-indigo-900/50 px-2 py-0.5 text-xs font-medium text-indigo-300">
                      {emitenList.find((e) => e.code === selectedEmiten)?.sector || ""}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-[#1e293b] bg-[#1e293b]/50 text-slate-300 hover:bg-[#1e293b] hover:text-white"
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    Unduh Laporan
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-[#1e293b] bg-[#1e293b]/50 text-slate-300 hover:bg-[#1e293b] hover:text-white"
                  >
                    <ChevronDown className="mr-2 h-4 w-4" />
                    Opsi Lainnya
                  </Button>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Financial Reports */}
          <Card className="border-[#1e293b] bg-[#0f172a] shadow-lg">
            <CardContent className="p-0">
              <Tabs defaultValue="overview" className="w-full">
                <div className="border-b border-[#1e293b] px-6">
                  <TabsList className="h-12 w-full justify-start gap-6 bg-transparent p-0">
                    <TabsTrigger
                      value="overview"
                      className="h-12 border-b-2 border-transparent text-slate-400 data-[state=active]:border-indigo-500 data-[state=active]:bg-transparent data-[state=active]:text-white data-[state=active]:shadow-none"
                    >
                      Ikhtisar
                    </TabsTrigger>
                    <TabsTrigger
                      value="income"
                      className="h-12 border-b-2 border-transparent text-slate-400 data-[state=active]:border-indigo-500 data-[state=active]:bg-transparent data-[state=active]:text-white data-[state=active]:shadow-none"
                    >
                      Laba Rugi
                    </TabsTrigger>
                    <TabsTrigger
                      value="balance"
                      className="h-12 border-b-2 border-transparent text-slate-400 data-[state=active]:border-indigo-500 data-[state=active]:bg-transparent data-[state=active]:text-white data-[state=active]:shadow-none"
                    >
                      Neraca
                    </TabsTrigger>
                    <TabsTrigger
                      value="cashflow"
                      className="h-12 border-b-2 border-transparent text-slate-400 data-[state=active]:border-indigo-500 data-[state=active]:bg-transparent data-[state=active]:text-white data-[state=active]:shadow-none"
                    >
                      Arus Kas
                    </TabsTrigger>
                  </TabsList>
                </div>

                {/* Overview Tab */}
                <TabsContent value="overview" className="m-0 p-6">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-[#1e293b] hover:bg-transparent">
                          <TableHead className="w-[300px] bg-[#1e293b] text-slate-300">Metrik</TableHead>
                          <TableHead className="bg-[#1e293b] text-slate-300">Nilai (dalam ribuan USD)</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {/* Pendapatan & Profitabilitas */}
                        <TableRow className="border-[#1e293b] hover:bg-[#1e293b]/50">
                          <TableCell className="font-medium text-white">Penjualan dan Pendapatan</TableCell>
                          <TableCell className="text-slate-300">1,084,004</TableCell>
                        </TableRow>
                        <TableRow className="border-[#1e293b] hover:bg-[#1e293b]/50">
                          <TableCell className="font-medium text-white">Laba Kotor</TableCell>
                          <TableCell className="text-slate-300">867,681</TableCell>
                        </TableRow>
                        <TableRow className="border-[#1e293b] hover:bg-[#1e293b]/50">
                          <TableCell className="font-medium text-white">Laba Rugi</TableCell>
                          <TableCell className="text-slate-300">1,854,878</TableCell>
                        </TableRow>

                        {/* Aset & Liabilitas */}
                        <TableRow className="border-[#1e293b] hover:bg-[#1e293b]/50">
                          <TableCell className="font-medium text-white">Kas dan Setara Kas</TableCell>
                          <TableCell className="text-slate-300">3,311,232</TableCell>
                        </TableRow>
                        <TableRow className="border-[#1e293b] hover:bg-[#1e293b]/50">
                          <TableCell className="font-medium text-white">Total Aset</TableCell>
                          <TableCell className="text-slate-300">10,472,711</TableCell>
                        </TableRow>

                        {/* Pinjaman */}
                        <TableRow className="border-[#1e293b] hover:bg-[#1e293b]/50">
                          <TableCell className="font-medium text-white">Pinjaman Bank Jangka Pendek</TableCell>
                          <TableCell className="text-slate-300">0</TableCell>
                        </TableRow>
                        <TableRow className="border-[#1e293b] hover:bg-[#1e293b]/50">
                          <TableCell className="font-medium text-white">Pinjaman Bank Jangka Panjang</TableCell>
                          <TableCell className="text-slate-300">404,361</TableCell>
                        </TableRow>

                        {/* Ekuitas */}
                        <TableRow className="border-[#1e293b] hover:bg-[#1e293b]/50">
                          <TableCell className="font-medium text-white">Ekuitas yang Dapat Diatribusikan kepada Pemilik Entitas Induk</TableCell>
                          <TableCell className="text-slate-300">6,772,664</TableCell>
                        </TableRow>

                        {/* Arus Kas */}
                        <TableRow className="border-[#1e293b] hover:bg-[#1e293b]/50">
                          <TableCell className="font-medium text-white">Arus Kas dari Aktivitas Operasi</TableCell>
                          <TableCell className="text-slate-300">1,152,758</TableCell>
                        </TableRow>
                        <TableRow className="border-[#1e293b] hover:bg-[#1e293b]/50">
                          <TableCell className="font-medium text-white">Arus Kas dari Aktivitas Investasi</TableCell>
                          <TableCell className="text-slate-300">-582,426</TableCell>
                        </TableRow>
                        <TableRow className="border-[#1e293b] hover:bg-[#1e293b]/50">
                          <TableCell className="font-medium text-white">Arus Kas dari Aktivitas Pendanaan</TableCell>
                          <TableCell className="text-slate-300">-1,333,690</TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>

                {/* Income Statement Tab */}
                <TabsContent value="income" className="m-0 p-6">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-[#1e293b] hover:bg-transparent">
                          <TableHead className="w-[250px] bg-[#1e293b] text-slate-300">Metrik</TableHead>
                          <TableHead className="bg-[#1e293b] text-slate-300">
                            {selectedPeriod === "q2_2023"
                              ? "Q2 2023"
                              : selectedPeriod === "q1_2023"
                                ? "Q1 2023"
                                : selectedPeriod === "q4_2022"
                                  ? "Q4 2022"
                                  : "Q3 2022"}
                          </TableHead>
                          <TableHead className="bg-[#1e293b] text-slate-300">
                            {selectedPeriod === "q2_2023"
                              ? "Q1 2023"
                              : selectedPeriod === "q1_2023"
                                ? "Q4 2022"
                                : selectedPeriod === "q4_2022"
                                  ? "Q3 2022"
                                  : "Q2 2022"}
                          </TableHead>
                          <TableHead className="bg-[#1e293b] text-slate-300">YoY %</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow className="border-[#1e293b] hover:bg-[#1e293b]/50">
                          <TableCell className="font-medium text-white">Pendapatan Bunga</TableCell>
                          <TableCell className="text-slate-300">Rp 18.2T</TableCell>
                          <TableCell className="text-slate-300">Rp 17.5T</TableCell>
                          <TableCell className="text-emerald-400">+4.0%</TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>

                {/* Balance Sheet Tab */}
                <TabsContent value="balance" className="m-0 p-6">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-[#1e293b] hover:bg-transparent">
                          <TableHead className="w-[250px] bg-[#1e293b] text-slate-300">Metrik</TableHead>
                          <TableHead className="bg-[#1e293b] text-slate-300">
                            {selectedPeriod === "q2_2023"
                              ? "Q2 2023"
                              : selectedPeriod === "q1_2023"
                                ? "Q1 2023"
                                : selectedPeriod === "q4_2022"
                                  ? "Q4 2022"
                                  : "Q3 2022"}
                          </TableHead>
                          <TableHead className="bg-[#1e293b] text-slate-300">
                            {selectedPeriod === "q2_2023"
                              ? "Q1 2023"
                              : selectedPeriod === "q1_2023"
                                ? "Q4 2022"
                                : selectedPeriod === "q4_2022"
                                  ? "Q3 2022"
                                  : "Q2 2022"}
                          </TableHead>
                          <TableHead className="bg-[#1e293b] text-slate-300">YoY %</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow className="border-[#1e293b] hover:bg-[#1e293b]/50">
                          <TableCell className="font-medium text-white">Total Aset</TableCell>
                          <TableCell className="text-slate-300">Rp 1,350T</TableCell>
                          <TableCell className="text-slate-300">Rp 1,320T</TableCell>
                          <TableCell className="text-emerald-400">+2.3%</TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>

                {/* Cash Flow Tab */}
                <TabsContent value="cashflow" className="m-0 p-6">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-[#1e293b] hover:bg-transparent">
                          <TableHead className="w-[250px] bg-[#1e293b] text-slate-300">Metrik</TableHead>
                          <TableHead className="bg-[#1e293b] text-slate-300">
                            {selectedPeriod === "q2_2023"
                              ? "Q2 2023"
                              : selectedPeriod === "q1_2023"
                                ? "Q1 2023"
                                : selectedPeriod === "q4_2022"
                                  ? "Q4 2022"
                                  : "Q3 2022"}
                          </TableHead>
                          <TableHead className="bg-[#1e293b] text-slate-300">
                            {selectedPeriod === "q2_2023"
                              ? "Q1 2023"
                              : selectedPeriod === "q1_2023"
                                ? "Q4 2022"
                                : selectedPeriod === "q4_2022"
                                  ? "Q3 2022"
                                  : "Q2 2022"}
                          </TableHead>
                          <TableHead className="bg-[#1e293b] text-slate-300">YoY %</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow className="border-[#1e293b] hover:bg-[#1e293b]/50">
                          <TableCell className="font-medium text-white">Arus Kas Operasi</TableCell>
                          <TableCell className="text-slate-300">Rp 15.2T</TableCell>
                          <TableCell className="text-slate-300">Rp 14.3T</TableCell>
                          <TableCell className="text-emerald-400">+6.3%</TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Notes and Analysis */}
          <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
            <Card className="border-[#1e293b] bg-[#0f172a] shadow-lg">
              <CardHeader className="border-b border-[#1e293b] px-6 pb-3 pt-4">
                <CardTitle className="text-base text-white">Catatan Laporan Keuangan</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4 text-sm text-slate-300">
                  <p>
                    Laporan keuangan {selectedEmiten} untuk periode{" "}
                    {selectedPeriod === "q2_2023"
                      ? "Q2 2023"
                      : selectedPeriod === "q1_2023"
                        ? "Q1 2023"
                        : selectedPeriod === "q4_2022"
                          ? "Q4 2022"
                          : "Q3 2022"}{" "}
                    telah disusun dan disajikan sesuai dengan Standar Akuntansi Keuangan di Indonesia.
                  </p>
                  <p>
                    Laporan keuangan ini telah diaudit oleh Kantor Akuntan Publik dengan pendapat wajar tanpa
                    pengecualian.
                  </p>
                  <p>
                    Seluruh angka yang disajikan dalam laporan keuangan ini dinyatakan dalam jutaan Rupiah, kecuali
                    dinyatakan lain.
                  </p>
                  <p>
                    Untuk informasi lebih lanjut, silakan merujuk ke laporan keuangan lengkap yang telah dipublikasikan
                    di situs web perusahaan.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-[#1e293b] bg-[#0f172a] shadow-lg">
              <CardHeader className="border-b border-[#1e293b] px-6 pb-3 pt-4">
                <CardTitle className="text-base text-white">Analisis Kinerja</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4 text-sm text-slate-300">
                  <p>
                    {selectedEmiten === "BBCA" ? (
                      <>
                        BCA mencatatkan pertumbuhan laba bersih sebesar 7.1% YoY pada Q2 2023, didorong oleh peningkatan
                        pendapatan bunga bersih dan pendapatan non-bunga yang tumbuh masing-masing sebesar 4.0% dan
                        11.9%.
                      </>
                    ) : selectedEmiten === "BBRI" ? (
                      <>
                        BRI menunjukkan kinerja yang solid dengan pertumbuhan laba bersih sebesar 7.0% YoY pada Q2 2023.
                        Pertumbuhan kredit yang kuat, terutama di segmen UMKM, menjadi pendorong utama kinerja positif
                        tersebut.
                      </>
                    ) : selectedEmiten === "TLKM" ? (
                      <>
                        Telkom Indonesia mencatatkan pertumbuhan laba bersih sebesar 2.4% YoY pada Q2 2023. Segmen
                        digital dan broadband menjadi kontributor utama pertumbuhan, mengimbangi perlambatan di segmen
                        legacy.
                      </>
                    ) : (
                      <>
                        Emiten ini menunjukkan kinerja yang stabil dengan pertumbuhan moderat pada periode pelaporan
                        terkini. Faktor utama yang mempengaruhi kinerja meliputi kondisi makroekonomi dan strategi
                        bisnis perusahaan.
                      </>
                    )}
                  </p>
                  <p>
                    Rasio keuangan utama menunjukkan kondisi yang sehat, dengan likuiditas dan solvabilitas yang terjaga
                    dengan baik. Manajemen terus fokus pada efisiensi operasional dan inovasi untuk mendorong
                    pertumbuhan berkelanjutan.
                  </p>
                  <p>
                    Prospek ke depan tetap positif, didukung oleh fundamental yang kuat dan strategi ekspansi yang
                    terarah. Namun, perlu diwaspadai risiko dari ketidakpastian global dan potensi perubahan regulasi.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
