// "use client"

// import { useState } from "react"
// import {
//   ArrowLeft,
//   ArrowRight,
//   Bell,
//   Calendar,
//   Clock,
//   ExternalLink,
//   Home,
//   Menu,
//   Search,
//   Settings,
//   TrendingUp,
// } from "lucide-react"
// import Link from "next/link"

// import { Button } from "@/components/ui/button"
// import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
// import { Input } from "@/components/ui/input"
// import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
// import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
// import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// export default function BeritaPage() {
//   const [searchQuery, setSearchQuery] = useState("")
//   const [expandedNews, setExpandedNews] = useState<number | null>(null)

//   // Sample news data
//   const newsData = [
//     {
//       id: 1,
//       title: "BCA Catat Pertumbuhan Laba 7% di Q2 2023",
//       summary:
//         "Bank Central Asia (BBCA) mencatatkan pertumbuhan laba bersih sebesar 7% YoY pada kuartal kedua 2023. Pencapaian ini didorong oleh peningkatan pendapatan bunga bersih sebesar 5,8% dan pendapatan non-bunga yang tumbuh 11,9%. Direktur Keuangan BCA, Vera Eve Lim, menyatakan bahwa pertumbuhan kredit yang solid di segmen korporasi dan konsumer menjadi pendorong utama kinerja positif tersebut.",
//       fullContent:
//         "Bank Central Asia (BBCA) mencatatkan pertumbuhan laba bersih sebesar 7% YoY pada kuartal kedua 2023. Pencapaian ini didorong oleh peningkatan pendapatan bunga bersih sebesar 5,8% dan pendapatan non-bunga yang tumbuh 11,9%. Direktur Keuangan BCA, Vera Eve Lim, menyatakan bahwa pertumbuhan kredit yang solid di segmen korporasi dan konsumer menjadi pendorong utama kinerja positif tersebut.\n\nLaba bersih BCA mencapai Rp 10,5 triliun pada Q2 2023, naik dari Rp 9,8 triliun pada periode yang sama tahun lalu. Pendapatan bunga bersih tercatat sebesar Rp 18,2 triliun, sementara pendapatan non-bunga mencapai Rp 7,5 triliun. Rasio kredit bermasalah (NPL) tetap terjaga di level 1,5%, menunjukkan kualitas aset yang baik.\n\nPada kesempatan yang sama, Presiden Direktur BCA, Jahja Setiaatmadja, mengungkapkan bahwa perseroan optimis dapat mencapai target pertumbuhan kredit sebesar 8-10% pada tahun 2023, didukung oleh pemulihan ekonomi yang berkelanjutan dan strategi ekspansi yang terarah.",
//       date: "15 Juli 2023",
//       time: "14:30 WIB",
//       source: "Investor Daily",
//       category: "Keuangan",
//       relatedStocks: ["BBCA", "BMRI", "BBRI"],
//       imageUrl: "/placeholder.svg?height=200&width=400",
//     },
//     {
//       id: 2,
//       title: "OJK Perketat Aturan Margin Trading untuk Perlindungan Investor",
//       summary:
//         "Otoritas Jasa Keuangan (OJK) mengeluarkan aturan baru terkait margin trading untuk meningkatkan perlindungan investor. Regulasi ini mewajibkan perusahaan sekuritas untuk menerapkan sistem manajemen risiko yang lebih ketat dan transparansi yang lebih baik kepada nasabah. Ketua Dewan Komisioner OJK, Mahendra Siregar, menekankan pentingnya edukasi investor terkait risiko margin trading.",
//       fullContent:
//         'Otoritas Jasa Keuangan (OJK) mengeluarkan aturan baru terkait margin trading untuk meningkatkan perlindungan investor. Regulasi ini mewajibkan perusahaan sekuritas untuk menerapkan sistem manajemen risiko yang lebih ketat dan transparansi yang lebih baik kepada nasabah. Ketua Dewan Komisioner OJK, Mahendra Siregar, menekankan pentingnya edukasi investor terkait risiko margin trading.\n\nAturan baru tersebut mencakup beberapa poin utama, di antaranya penurunan rasio maksimum fasilitas pembiayaan dari 65% menjadi 60% dari nilai portofolio, peningkatan persyaratan margin call, serta kewajiban perusahaan sekuritas untuk memberikan simulasi risiko kepada nasabah sebelum membuka fasilitas margin.\n\n"Kami ingin memastikan bahwa investor memahami sepenuhnya risiko yang terkait dengan margin trading, terutama dalam kondisi pasar yang volatil," ujar Mahendra dalam konferensi pers virtual pada Rabu (12/7). Aturan baru ini akan mulai berlaku efektif pada 1 Oktober 2023, dengan masa transisi selama tiga bulan bagi perusahaan sekuritas untuk menyesuaikan sistem mereka.',
//       date: "12 Juli 2023",
//       time: "10:15 WIB",
//       source: "CNBC Indonesia",
//       category: "Regulasi",
//       relatedStocks: ["PANS", "TRIM", "SRTG"],
//       imageUrl: "/placeholder.svg?height=200&width=400",
//     },
//     {
//       id: 3,
//       title: "Ekonom: Pertumbuhan Ekonomi Indonesia Capai 5.2% di Q2 2023",
//       summary:
//         "Para ekonom memperkirakan pertumbuhan ekonomi Indonesia mencapai 5,2% pada kuartal kedua 2023, didorong oleh konsumsi domestik yang kuat dan peningkatan ekspor. Angka ini lebih tinggi dari pertumbuhan 5,0% pada kuartal pertama. Ekonom Senior Bank Mandiri, Andry Asmoro, menyatakan bahwa sektor konsumsi rumah tangga menjadi kontributor utama, dengan pertumbuhan mencapai 5,4% YoY.",
//       fullContent:
//         'Para ekonom memperkirakan pertumbuhan ekonomi Indonesia mencapai 5,2% pada kuartal kedua 2023, didorong oleh konsumsi domestik yang kuat dan peningkatan ekspor. Angka ini lebih tinggi dari pertumbuhan 5,0% pada kuartal pertama. Ekonom Senior Bank Mandiri, Andry Asmoro, menyatakan bahwa sektor konsumsi rumah tangga menjadi kontributor utama, dengan pertumbuhan mencapai 5,4% YoY.\n\nSurvei yang dilakukan oleh Bloomberg terhadap 24 ekonom menunjukkan proyeksi pertumbuhan ekonomi Indonesia berada dalam rentang 5,0% hingga 5,4% untuk Q2 2023. Faktor pendorong utama meliputi peningkatan mobilitas masyarakat pasca-pandemi, momentum Ramadan dan Idul Fitri, serta kinerja ekspor yang tetap solid meskipun ada perlambatan permintaan global.\n\n"Kami melihat tren positif dari indikator-indikator utama seperti penjualan ritel, indeks keyakinan konsumen, dan produksi industri," kata Josua Pardede, Ekonom Kepala Bank Permata. "Namun, perlu diwaspadai risiko dari ketidakpastian global dan potensi kenaikan inflasi akibat El Niño yang dapat memengaruhi harga pangan."\n\nBadan Pusat Statistik (BPS) dijadwalkan akan merilis data resmi pertumbuhan ekonomi Indonesia kuartal kedua pada awal Agustus mendatang.',
//       date: "10 Juli 2023",
//       time: "09:45 WIB",
//       source: "Bisnis Indonesia",
//       category: "Ekonomi",
//       relatedStocks: ["BBRI", "ASII", "TLKM"],
//       imageUrl: "/placeholder.svg?height=200&width=400",
//     },
//     {
//       id: 4,
//       title: "Telkom Indonesia Luncurkan Layanan 5G di 10 Kota Besar",
//       summary:
//         "PT Telkom Indonesia (TLKM) melalui anak usahanya Telkomsel resmi meluncurkan layanan 5G di 10 kota besar Indonesia. Direktur Utama Telkom, Ririek Adriansyah, mengatakan ekspansi ini merupakan bagian dari strategi transformasi digital perusahaan. Investasi untuk pengembangan infrastruktur 5G mencapai Rp 10 triliun untuk tahun 2023.",
//       fullContent:
//         'PT Telkom Indonesia (TLKM) melalui anak usahanya Telkomsel resmi meluncurkan layanan 5G di 10 kota besar Indonesia. Direktur Utama Telkom, Ririek Adriansyah, mengatakan ekspansi ini merupakan bagian dari strategi transformasi digital perusahaan. Investasi untuk pengembangan infrastruktur 5G mencapai Rp 10 triliun untuk tahun 2023.\n\nKota-kota yang mendapatkan layanan 5G Telkomsel meliputi Jakarta, Surabaya, Medan, Bandung, Makassar, Denpasar, Semarang, Yogyakarta, Palembang, dan Balikpapan. Perusahaan menargetkan cakupan layanan 5G mencapai 30% populasi Indonesia pada akhir 2023.\n\n"Pengembangan jaringan 5G merupakan komitmen kami untuk mendukung percepatan transformasi digital Indonesia," ujar Ririek dalam acara peluncuran di Jakarta, Senin (3/7). "Teknologi ini akan membuka peluang baru bagi industri, UMKM, dan masyarakat untuk berinovasi dan meningkatkan produktivitas."\n\nMenteri Komunikasi dan Informatika, Budi Arie Setiadi, yang hadir dalam acara tersebut menyambut baik inisiatif Telkom dan menyatakan bahwa pemerintah akan terus mendukung pengembangan infrastruktur digital melalui kebijakan yang kondusif dan alokasi spektrum yang optimal.',
//       date: "3 Juli 2023",
//       time: "13:20 WIB",
//       source: "Kompas Tekno",
//       category: "Teknologi",
//       relatedStocks: ["TLKM", "EXCL", "ISAT"],
//       imageUrl: "/placeholder.svg?height=200&width=400",
//     },
//     {
//       id: 5,
//       title: "Bank Indonesia Pertahankan Suku Bunga Acuan di Level 5,75%",
//       summary:
//         "Bank Indonesia (BI) memutuskan untuk mempertahankan suku bunga acuan BI Rate di level 5,75% dalam Rapat Dewan Gubernur (RDG) bulan Juli. Gubernur BI, Perry Warjiyo, menyatakan keputusan ini sejalan dengan upaya menjaga stabilitas nilai tukar rupiah dan mengendalikan inflasi dalam kisaran target 2-4% pada tahun 2023.",
//       fullContent:
//         'Bank Indonesia (BI) memutuskan untuk mempertahankan suku bunga acuan BI Rate di level 5,75% dalam Rapat Dewan Gubernur (RDG) bulan Juli. Gubernur BI, Perry Warjiyo, menyatakan keputusan ini sejalan dengan upaya menjaga stabilitas nilai tukar rupiah dan mengendalikan inflasi dalam kisaran target 2-4% pada tahun 2023.\n\n"Keputusan ini mempertimbangkan beberapa faktor, termasuk tren inflasi yang terkendali, stabilitas eksternal yang terjaga, serta prospek pertumbuhan ekonomi yang tetap kuat," kata Perry dalam konferensi pers virtual pasca-RDG pada Kamis (20/7).\n\nBI juga mempertahankan suku bunga Deposit Facility di level 5,00% dan suku bunga Lending Facility di level 6,50%. Perry menambahkan bahwa BI akan terus memperkuat koordinasi dengan pemerintah dan otoritas terkait untuk menjaga stabilitas makroekonomi dan sistem keuangan guna mendukung pertumbuhan ekonomi yang berkelanjutan.\n\nMenanggapi keputusan BI, ekonom dari berbagai lembaga keuangan menyatakan bahwa hal ini sudah sesuai ekspektasi pasar. Mereka memperkirakan BI akan mempertahankan suku bunga acuan setidaknya hingga akhir kuartal ketiga 2023, dengan potensi penurunan pada kuartal keempat jika inflasi tetap terkendali dan The Fed mulai memangkas suku bunga.',
//       date: "20 Juli 2023",
//       time: "15:45 WIB",
//       source: "Kontan",
//       category: "Moneter",
//       relatedStocks: ["BBRI", "BMRI", "BBCA", "BBNI"],
//       imageUrl: "/placeholder.svg?height=200&width=400",
//     },
//     {
//       id: 6,
//       title: "BBRI Luncurkan Program Pembiayaan UMKM dengan Bunga Rendah",
//       summary:
//         "Bank Rakyat Indonesia (BBRI) meluncurkan program pembiayaan khusus untuk UMKM dengan suku bunga kompetitif mulai dari 5,5% per tahun. Program ini bertujuan mendukung pemulihan ekonomi nasional melalui penguatan sektor UMKM yang menjadi tulang punggung ekonomi Indonesia.",
//       fullContent:
//         "Bank Rakyat Indonesia (BBRI) meluncurkan program pembiayaan khusus untuk UMKM dengan suku bunga kompetitif mulai dari 5,5% per tahun. Program ini bertujuan mendukung pemulihan ekonomi nasional melalui penguatan sektor UMKM yang menjadi tulang punggung ekonomi Indonesia.\n\nDalam konferensi pers virtual pada Senin (17/7), Direktur Utama BRI, Sunarso, menjelaskan bahwa program ini merupakan bagian dari komitmen BRI untuk menjadi 'The Best Financial Service Provider in Southeast Asia' dengan fokus pada pemberdayaan UMKM.\n\n\"BRI telah mengalokasikan dana sebesar Rp 50 triliun untuk program ini, dengan target menjangkau lebih dari 500.000 pelaku UMKM di seluruh Indonesia,\" ujar Sunarso. Program ini menawarkan tenor hingga 5 tahun dengan proses persetujuan yang dipercepat melalui digitalisasi proses kredit.\n\nSelain pembiayaan, BRI juga menyediakan pendampingan bisnis dan pelatihan digital untuk membantu UMKM beradaptasi dengan era ekonomi digital. Inisiatif ini mendapat sambutan positif dari Kementerian Koperasi dan UKM yang melihatnya sebagai kontribusi signifikan terhadap target pertumbuhan UMKM digital.",
//       date: "17 Juli 2023",
//       time: "11:20 WIB",
//       source: "Bisnis Indonesia",
//       category: "Keuangan",
//       relatedStocks: ["BBRI", "BMRI", "BBNI"],
//       imageUrl: "/placeholder.svg?height=200&width=400",
//     },
//     {
//       id: 7,
//       title: "TLKM Perluas Jaringan 5G ke 15 Kota Baru Tahun Ini",
//       summary:
//         "PT Telkom Indonesia (TLKM) mengumumkan rencana ekspansi jaringan 5G ke 15 kota baru pada tahun 2023. Ekspansi ini merupakan lanjutan dari peluncuran awal di 10 kota besar dan bertujuan mempercepat transformasi digital di Indonesia.",
//       fullContent:
//         'PT Telkom Indonesia (TLKM) mengumumkan rencana ekspansi jaringan 5G ke 15 kota baru pada tahun 2023. Ekspansi ini merupakan lanjutan dari peluncuran awal di 10 kota besar dan bertujuan mempercepat transformasi digital di Indonesia.\n\nDirektur Network & IT Solution Telkom, Herlan Wijanarko, mengatakan bahwa 15 kota yang akan mendapatkan layanan 5G meliputi Malang, Pekanbaru, Banjarmasin, Manado, Ambon, Mataram, Kupang, Pontianak, Jambi, Bengkulu, Kendari, Palu, Gorontalo, Mamuju, dan Jayapura.\n\n"Dengan ekspansi ini, kami menargetkan cakupan layanan 5G mencapai 45% populasi Indonesia pada akhir 2023, meningkat dari target awal 30%," jelas Herlan dalam paparan kinerja perusahaan di Jakarta, Jumat (21/7).\n\nTelkom telah mengalokasikan belanja modal (capex) sebesar Rp 5 triliun khusus untuk pengembangan infrastruktur 5G tahun ini. Perusahaan juga menjalin kemitraan strategis dengan vendor teknologi global untuk memastikan implementasi yang efisien dan handal.\n\nAnalis dari Mirae Asset Sekuritas, Christine Natasya, menilai ekspansi 5G Telkom akan menjadi katalis positif bagi pertumbuhan pendapatan perusahaan dalam jangka menengah, terutama dari segmen digital dan enterprise.',
//       date: "21 Juli 2023",
//       time: "14:45 WIB",
//       source: "Kompas Tekno",
//       category: "Teknologi",
//       relatedStocks: ["TLKM", "EXCL", "ISAT"],
//       imageUrl: "/placeholder.svg?height=200&width=400",
//     },
//     {
//       id: 8,
//       title: "ASII Catat Kenaikan Penjualan Mobil 12% di Semester I 2023",
//       summary:
//         "PT Astra International Tbk (ASII) mencatatkan peningkatan penjualan mobil sebesar 12% YoY pada semester pertama 2023. Total penjualan mencapai 283.500 unit, dengan kontribusi terbesar dari segmen MPV dan SUV. Direktur ASII menyatakan optimisme terhadap prospek industri otomotif di tengah pemulihan ekonomi.",
//       fullContent:
//         'PT Astra International Tbk (ASII) mencatatkan peningkatan penjualan mobil sebesar 12% YoY pada semester pertama 2023. Total penjualan mencapai 283.500 unit, dengan kontribusi terbesar dari segmen MPV dan SUV. Direktur ASII menyatakan optimisme terhadap prospek industri otomotif di tengah pemulihan ekonomi.\n\nBerdasarkan data yang dirilis pada Rabu (19/7), penjualan Toyota mendominasi dengan 106.800 unit (naik 15% YoY), diikuti Daihatsu dengan 85.300 unit (naik 10% YoY), dan Isuzu dengan 15.200 unit (naik 8% YoY).\n\n"Peningkatan penjualan ini didorong oleh peluncuran beberapa model baru, program insentif pemerintah, serta pemulihan rantai pasok yang lebih baik dibandingkan tahun lalu," ujar Direktur ASII, Gidion Hasan, dalam keterangan resmi.\n\nSegmen kendaraan ramah lingkungan (low emission vehicle) juga menunjukkan pertumbuhan signifikan, dengan penjualan mencapai 27.500 unit atau naik 45% YoY. ASII menargetkan segmen ini akan berkontribusi 20% dari total penjualan pada akhir 2023.\n\nSementara itu, untuk pasar ekspor, ASII mencatat pengiriman sebanyak 112.300 unit kendaraan completely built up (CBU) dan completely knocked down (CKD), atau naik 18% dibandingkan periode yang sama tahun lalu.',
//       date: "19 Juli 2023",
//       time: "10:30 WIB",
//       source: "Otomotif Bisnis",
//       category: "Otomotif",
//       relatedStocks: ["ASII", "AUTO", "IMAS"],
//       imageUrl: "/placeholder.svg?height=200&width=400",
//     },
//     {
//       id: 9,
//       title: "UNVR Laporkan Pertumbuhan Penjualan 5,3% di Q2 2023",
//       summary:
//         "PT Unilever Indonesia Tbk (UNVR) melaporkan pertumbuhan penjualan sebesar 5,3% YoY pada kuartal kedua 2023. Segmen home and personal care menjadi pendorong utama dengan pertumbuhan 6,2%, sementara segmen makanan dan minuman tumbuh 4,1%. Margin laba bersih sedikit tertekan akibat kenaikan biaya bahan baku.",
//       fullContent:
//         'PT Unilever Indonesia Tbk (UNVR) melaporkan pertumbuhan penjualan sebesar 5,3% YoY pada kuartal kedua 2023. Segmen home and personal care menjadi pendorong utama dengan pertumbuhan 6,2%, sementara segmen makanan dan minuman tumbuh 4,1%. Margin laba bersih sedikit tertekan akibat kenaikan biaya bahan baku.\n\nDalam laporan keuangan yang dirilis Kamis (20/7), UNVR mencatat penjualan bersih sebesar Rp 12,8 triliun pada Q2 2023, naik dari Rp 12,15 triliun pada periode yang sama tahun lalu. Laba bersih tercatat sebesar Rp 1,85 triliun, tumbuh 3,9% YoY.\n\n"Di tengah tantangan inflasi dan perubahan perilaku konsumen, kami berhasil mempertahankan momentum pertumbuhan melalui inovasi produk dan efisiensi operasional," kata Direktur Keuangan UNVR, Ainul Yaqin, dalam konferensi pers virtual.\n\nPerusahaan meluncurkan 12 produk baru dan varian pada kuartal kedua, termasuk rangkaian produk perawatan kulit berbahan alami dan minuman kesehatan. Strategi digitalisasi juga terus diperkuat, dengan penjualan melalui e-commerce tumbuh 25% YoY dan kini menyumbang 15% dari total penjualan.\n\nUntuk paruh kedua 2023, UNVR memperkirakan pertumbuhan moderat di kisaran 4-6%, dengan fokus pada inovasi premium dan perluasan distribusi di luar Jawa.',
//       date: "20 Juli 2023",
//       time: "16:15 WIB",
//       source: "Investor Daily",
//       category: "Konsumer",
//       relatedStocks: ["UNVR", "ICBP", "MYOR"],
//       imageUrl: "/placeholder.svg?height=200&width=400",
//     },
//     {
//       id: 10,
//       title: "BBNI Targetkan Pertumbuhan Kredit 8-10% Tahun 2023",
//       summary:
//         "PT Bank Negara Indonesia Tbk (BBNI) menargetkan pertumbuhan kredit sebesar 8-10% pada tahun 2023. Direktur Utama BBNI, Royke Tumilaar, menyatakan bahwa segmen korporasi dan UKM akan menjadi fokus utama ekspansi kredit. Bank juga akan memperkuat layanan digital untuk meningkatkan fee-based income.",
//       fullContent:
//         'PT Bank Negara Indonesia Tbk (BBNI) menargetkan pertumbuhan kredit sebesar 8-10% pada tahun 2023. Direktur Utama BBNI, Royke Tumilaar, menyatakan bahwa segmen korporasi dan UKM akan menjadi fokus utama ekspansi kredit. Bank juga akan memperkuat layanan digital untuk meningkatkan fee-based income.\n\n"Kami melihat peluang pertumbuhan yang baik di sektor infrastruktur, energi terbarukan, dan industri pengolahan yang berorientasi ekspor," ujar Royke dalam paparan kinerja semester I-2023 di Jakarta, Selasa (18/7).\n\nPada semester pertama 2023, BBNI telah mencatatkan pertumbuhan kredit sebesar 6,2% YoY menjadi Rp 650,7 triliun. Kredit korporasi tumbuh 7,5%, sementara kredit UKM tumbuh 5,8%. Dari sisi pendanaan, dana pihak ketiga tumbuh 5,3% YoY menjadi Rp 725,3 triliun.\n\nBBNI juga melaporkan peningkatan signifikan pada transaksi digital, dengan volume transaksi melalui BNI Mobile Banking naik 35% YoY. Fee-based income dari layanan digital menyumbang 25% dari total pendapatan non-bunga bank.\n\n"Transformasi digital menjadi kunci strategi kami untuk meningkatkan efisiensi dan layanan nasabah," tambah Royke. BBNI telah mengalokasikan anggaran teknologi sebesar Rp 3,5 triliun untuk tahun 2023, naik 20% dari tahun sebelumnya.',
//       date: "18 Juli 2023",
//       time: "13:40 WIB",
//       source: "CNBC Indonesia",
//       category: "Keuangan",
//       relatedStocks: ["BBNI", "BBRI", "BMRI", "BBCA"],
//       imageUrl: "/placeholder.svg?height=200&width=400",
//     },
//   ]

//   // Filter news based on search query
//   const filteredNews = newsData.filter((news) => {
//     // If there's no search query, return all news
//     if (!searchQuery.trim()) return true

//     // Check if search query matches any related stock directly (case insensitive)
//     const searchLower = searchQuery.toLowerCase()
//     if (news.relatedStocks.some((stock) => stock.toLowerCase() === searchLower)) {
//       return true
//     }

//     // Otherwise check other fields
//     return (
//       news.title.toLowerCase().includes(searchLower) ||
//       news.summary.toLowerCase().includes(searchLower) ||
//       news.category.toLowerCase().includes(searchLower) ||
//       news.relatedStocks.some((stock) => stock.toLowerCase().includes(searchLower))
//     )
//   })

//   const toggleExpandNews = (id: number) => {
//     if (expandedNews === id) {
//       setExpandedNews(null)
//     } else {
//       setExpandedNews(id)
//     }
//   }

//   return (
//     <div className="flex min-h-screen bg-[#0f172a]">
//       {/* Sidebar */}
//       <div className="hidden w-64 flex-col border-r border-[#1e293b] bg-[#0f172a] md:flex">
//         <div className="flex h-16 items-center border-b border-[#1e293b] px-6">
//           <Link href="/dashboard" className="flex items-center gap-2 text-lg font-semibold text-white">
//             <div className="flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-indigo-500 to-purple-600 text-white">
//               <TrendingUp className="h-5 w-5" />
//             </div>
//             <span className="font-bold">FinanceHub</span>
//           </Link>
//         </div>
//         <div className="flex-1 overflow-auto px-3 py-4">
//           <div className="mb-6 px-3">
//             <div className="relative">
//               <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
//               <Input
//                 type="search"
//                 placeholder="Cari berita..."
//                 className="w-full border-[#1e293b] bg-[#1e293b] pl-8 text-slate-300 shadow-none placeholder:text-slate-500 focus-visible:ring-1 focus-visible:ring-indigo-500"
//                 value={searchQuery}
//                 onChange={(e) => setSearchQuery(e.target.value)}
//               />
//             </div>
//           </div>
//           <div className="space-y-1 px-3 py-2">
//             <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">Menu Utama</p>
//             <Button variant="ghost" className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white">
//               <Home className="mr-2 h-4 w-4" />
//               <Link href="/dashboard">Dashboard</Link>
//             </Button>
//             <Button variant="ghost" className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white">
//               <Calendar className="mr-2 h-4 w-4" />
//               <Link href="/laporan-keuangan">Laporan Keuangan</Link>
//             </Button>
//             <Button
//               variant="ghost"
//               className="w-full justify-start bg-[#1e293b] text-white hover:bg-[#2d3c52] hover:text-white"
//             >
//               <ExternalLink className="mr-2 h-4 w-4" />
//               Berita
//             </Button>
//           </div>
//           <div className="mt-6 space-y-1 px-3 py-2">
//             <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">Kategori Berita</p>
//             <Button variant="ghost" className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white">
//               Semua
//             </Button>
//             <Button variant="ghost" className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white">
//               Keuangan
//             </Button>
//             <Button variant="ghost" className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white">
//               Ekonomi
//             </Button>
//             <Button variant="ghost" className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white">
//               Regulasi
//             </Button>
//             <Button variant="ghost" className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white">
//               Teknologi
//             </Button>
//             <Button variant="ghost" className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white">
//               Moneter
//             </Button>
//           </div>
//         </div>
//         <div className="border-t border-[#1e293b] p-4">
//           <div className="flex items-center justify-between">
//             <div className="text-xs text-slate-400">
//               <Clock className="mr-1 inline-block h-3.5 w-3.5" />
//               <span>Update: 15:30 WIB</span>
//             </div>
//             <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-white">
//               <Settings className="h-4 w-4" />
//             </Button>
//           </div>
//         </div>
//       </div>

//       {/* Main Content */}
//       <div className="flex-1">
//         <header className="sticky top-0 z-10 flex h-16 items-center justify-between border-b border-[#1e293b] bg-[#0f172a]/80 px-4 backdrop-blur-sm md:px-6">
//           <div className="flex items-center gap-4">
//             <Sheet>
//               <SheetTrigger asChild>
//                 <Button variant="ghost" size="icon" className="md:hidden">
//                   <Menu className="h-5 w-5 text-slate-400" />
//                   <span className="sr-only">Toggle Menu</span>
//                 </Button>
//               </SheetTrigger>
//               <SheetContent side="left" className="w-72 border-r border-[#1e293b] bg-[#0f172a] p-0">
//                 <div className="flex h-16 items-center border-b border-[#1e293b] px-6">
//                   <Link href="/dashboard" className="flex items-center gap-2 text-lg font-semibold text-white">
//                     <div className="flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-indigo-500 to-purple-600 text-white">
//                       <TrendingUp className="h-5 w-5" />
//                     </div>
//                     <span className="font-bold">FinanceHub</span>
//                   </Link>
//                 </div>
//                 <div className="px-3 py-4">
//                   <div className="mb-6 px-3">
//                     <div className="relative">
//                       <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
//                       <Input
//                         type="search"
//                         placeholder="Cari berita..."
//                         className="w-full border-[#1e293b] bg-[#1e293b] pl-8 text-slate-300 shadow-none placeholder:text-slate-500 focus-visible:ring-1 focus-visible:ring-indigo-500"
//                         value={searchQuery}
//                         onChange={(e) => setSearchQuery(e.target.value)}
//                       />
//                     </div>
//                   </div>
//                   <div className="space-y-1 px-3 py-2">
//                     <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">Menu Utama</p>
//                     <Button
//                       variant="ghost"
//                       className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white"
//                     >
//                       <Home className="mr-2 h-4 w-4" />
//                       <Link href="/dashboard">Dashboard</Link>
//                     </Button>
//                     <Button
//                       variant="ghost"
//                       className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white"
//                     >
//                       <Calendar className="mr-2 h-4 w-4" />
//                       <Link href="/laporan-keuangan">Laporan Keuangan</Link>
//                     </Button>
//                     <Button
//                       variant="ghost"
//                       className="w-full justify-start bg-[#1e293b] text-white hover:bg-[#2d3c52] hover:text-white"
//                     >
//                       <ExternalLink className="mr-2 h-4 w-4" />
//                       Berita
//                     </Button>
//                   </div>
//                   <div className="mt-6 space-y-1 px-3 py-2">
//                     <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
//                       Kategori Berita
//                     </p>
//                     <Button
//                       variant="ghost"
//                       className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white"
//                     >
//                       Semua
//                     </Button>
//                     <Button
//                       variant="ghost"
//                       className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white"
//                     >
//                       Keuangan
//                     </Button>
//                     <Button
//                       variant="ghost"
//                       className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white"
//                     >
//                       Ekonomi
//                     </Button>
//                     <Button
//                       variant="ghost"
//                       className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white"
//                     >
//                       Regulasi
//                     </Button>
//                     <Button
//                       variant="ghost"
//                       className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white"
//                     >
//                       Teknologi
//                     </Button>
//                     <Button
//                       variant="ghost"
//                       className="w-full justify-start text-slate-400 hover:bg-[#1e293b] hover:text-white"
//                     >
//                       Moneter
//                     </Button>
//                   </div>
//                 </div>
//               </SheetContent>
//             </Sheet>
//             <h1 className="text-xl font-semibold text-white">Berita Pasar Modal</h1>
//           </div>
//           <div className="flex items-center gap-3">
//             <div className="hidden items-center gap-1 rounded-full bg-indigo-900/50 px-3 py-1 text-sm text-indigo-300 md:flex">
//               <Clock className="h-3.5 w-3.5" />
//               <span>Update: 15:30 WIB</span>
//             </div>
//             <Select defaultValue="terbaru">
//               <SelectTrigger className="w-[150px] border-[#1e293b] bg-[#1e293b] text-slate-300">
//                 <SelectValue placeholder="Urutkan" />
//               </SelectTrigger>
//               <SelectContent className="border-[#1e293b] bg-[#0f172a] text-slate-300">
//                 <SelectItem value="terbaru">Terbaru</SelectItem>
//                 <SelectItem value="terlama">Terlama</SelectItem>
//                 <SelectItem value="populer">Terpopuler</SelectItem>
//               </SelectContent>
//             </Select>
//             <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white">
//               <Bell className="h-4 w-4" />
//               <span className="sr-only">Notifikasi</span>
//             </Button>
//           </div>
//         </header>

//         <div className="p-4 md:p-6">
//           <div className="mb-6">
//             <Tabs defaultValue="semua" className="w-full">
//               <TabsList className="mb-4 grid w-full grid-cols-3 bg-[#1e293b] md:w-auto md:grid-cols-6">
//                 <TabsTrigger value="semua">Semua</TabsTrigger>
//                 <TabsTrigger value="keuangan">Keuangan</TabsTrigger>
//                 <TabsTrigger value="ekonomi">Ekonomi</TabsTrigger>
//                 <TabsTrigger value="regulasi">Regulasi</TabsTrigger>
//                 <TabsTrigger value="teknologi">Teknologi</TabsTrigger>
//                 <TabsTrigger value="moneter">Moneter</TabsTrigger>
//               </TabsList>
//               <TabsContent value="semua" className="m-0">
//                 <div className="grid gap-6">
//                   {filteredNews.length > 0 ? (
//                     filteredNews.map((news) => (
//                       <Card key={news.id} className="overflow-hidden border-[#1e293b] bg-[#0f172a] shadow-lg">
//                         <CardHeader className="border-b border-[#1e293b] px-6 pb-4 pt-5">
//                           <div className="flex flex-col gap-2">
//                             <div className="flex items-center gap-2">
//                               <div className="rounded-full bg-indigo-900/50 px-2 py-0.5 text-xs font-medium text-indigo-300">
//                                 {news.category}
//                               </div>
//                               <div className="flex items-center gap-1 text-xs text-slate-400">
//                                 <Calendar className="h-3 w-3" />
//                                 <span>{news.date}</span>
//                               </div>
//                               <div className="flex items-center gap-1 text-xs text-slate-400">
//                                 <Clock className="h-3 w-3" />
//                                 <span>{news.time}</span>
//                               </div>
//                             </div>
//                             <CardTitle className="text-xl text-white">{news.title}</CardTitle>
//                             <CardDescription className="text-slate-400">
//                               Sumber: {news.source} | Terkait: {news.relatedStocks.join(", ")}
//                             </CardDescription>
//                           </div>
//                         </CardHeader>
//                         <CardContent className="p-6">
//                           <div className="mb-4">
//                             <p className="text-slate-300">
//                               {expandedNews === news.id ? news.fullContent : news.summary}
//                             </p>
//                           </div>
//                           <div className="flex justify-between">
//                             <Button
//                               variant="outline"
//                               className="border-[#1e293b] bg-[#1e293b]/50 text-slate-300 hover:bg-[#1e293b] hover:text-white"
//                               onClick={() => toggleExpandNews(news.id)}
//                             >
//                               {expandedNews === news.id ? (
//                                 <>
//                                   <ArrowUp className="mr-2 h-4 w-4" /> Lihat Ringkasan
//                                 </>
//                               ) : (
//                                 <>
//                                   <ArrowDown className="mr-2 h-4 w-4" /> Baca Selengkapnya
//                                 </>
//                               )}
//                             </Button>
//                             <Button
//                               variant="outline"
//                               className="border-[#1e293b] bg-[#1e293b]/50 text-slate-300 hover:bg-[#1e293b] hover:text-white"
//                             >
//                               <ExternalLink className="mr-2 h-4 w-4" /> Buka di Sumber
//                             </Button>
//                           </div>
//                         </CardContent>
//                       </Card>
//                     ))
//                   ) : (
//                     <div className="flex h-40 flex-col items-center justify-center rounded-lg border border-[#1e293b] bg-[#0f172a]/50 p-6 text-center">
//                       <p className="mb-2 text-lg font-medium text-slate-300">Tidak ada berita yang ditemukan</p>
//                       <p className="text-sm text-slate-400">Coba gunakan kata kunci pencarian yang berbeda</p>
//                     </div>
//                   )}
//                 </div>
//               </TabsContent>

//               {/* Other tab contents would be similar but filtered by category */}
//               <TabsContent value="keuangan" className="m-0">
//                 <div className="grid gap-6">
//                   {filteredNews
//                     .filter((news) => news.category === "Keuangan")
//                     .map((news) => (
//                       <Card key={news.id} className="overflow-hidden border-[#1e293b] bg-[#0f172a] shadow-lg">
//                         {/* Same card content as above */}
//                         <CardHeader className="border-b border-[#1e293b] px-6 pb-4 pt-5">
//                           <div className="flex flex-col gap-2">
//                             <div className="flex items-center gap-2">
//                               <div className="rounded-full bg-indigo-900/50 px-2 py-0.5 text-xs font-medium text-indigo-300">
//                                 {news.category}
//                               </div>
//                               <div className="flex items-center gap-1 text-xs text-slate-400">
//                                 <Calendar className="h-3 w-3" />
//                                 <span>{news.date}</span>
//                               </div>
//                               <div className="flex items-center gap-1 text-xs text-slate-400">
//                                 <Clock className="h-3 w-3" />
//                                 <span>{news.time}</span>
//                               </div>
//                             </div>
//                             <CardTitle className="text-xl text-white">{news.title}</CardTitle>
//                             <CardDescription className="text-slate-400">
//                               Sumber: {news.source} | Terkait: {news.relatedStocks.join(", ")}
//                             </CardDescription>
//                           </div>
//                         </CardHeader>
//                         <CardContent className="p-6">
//                           <div className="mb-4">
//                             <p className="text-slate-300">
//                               {expandedNews === news.id ? news.fullContent : news.summary}
//                             </p>
//                           </div>
//                           <div className="flex justify-between">
//                             <Button
//                               variant="outline"
//                               className="border-[#1e293b] bg-[#1e293b]/50 text-slate-300 hover:bg-[#1e293b] hover:text-white"
//                               onClick={() => toggleExpandNews(news.id)}
//                             >
//                               {expandedNews === news.id ? (
//                                 <>
//                                   <ArrowUp className="mr-2 h-4 w-4" /> Lihat Ringkasan
//                                 </>
//                               ) : (
//                                 <>
//                                   <ArrowDown className="mr-2 h-4 w-4" /> Baca Selengkapnya
//                                 </>
//                               )}
//                             </Button>
//                             <Button
//                               variant="outline"
//                               className="border-[#1e293b] bg-[#1e293b]/50 text-slate-300 hover:bg-[#1e293b] hover:text-white"
//                             >
//                               <ExternalLink className="mr-2 h-4 w-4" /> Buka di Sumber
//                             </Button>
//                           </div>
//                         </CardContent>
//                       </Card>
//                     ))}
//                 </div>
//               </TabsContent>

//               {/* Similar structure for other tabs */}
//             </Tabs>
//           </div>

//           {/* Pagination */}
//           <div className="mt-8 flex items-center justify-center gap-2">
//             <Button
//               variant="outline"
//               size="icon"
//               className="h-8 w-8 border-[#1e293b] bg-[#1e293b]/50 text-slate-300 hover:bg-[#1e293b] hover:text-white"
//             >
//               <ArrowLeft className="h-4 w-4" />
//             </Button>
//             <Button variant="outline" className="h-8 border-[#1e293b] bg-[#1e293b] text-white hover:bg-[#2d3c52]">
//               1
//             </Button>
//             <Button
//               variant="outline"
//               className="h-8 border-[#1e293b] bg-[#1e293b]/50 text-slate-300 hover:bg-[#1e293b] hover:text-white"
//             >
//               2
//             </Button>
//             <Button
//               variant="outline"
//               className="h-8 border-[#1e293b] bg-[#1e293b]/50 text-slate-300 hover:bg-[#1e293b] hover:text-white"
//             >
//               3
//             </Button>
//             <Button
//               variant="outline"
//               className="h-8 border-[#1e293b] bg-[#1e293b]/50 text-slate-300 hover:bg-[#1e293b] hover:text-white"
//             >
//               ...
//             </Button>
//             <Button
//               variant="outline"
//               className="h-8 border-[#1e293b] bg-[#1e293b]/50 text-slate-300 hover:bg-[#1e293b] hover:text-white"
//             >
//               10
//             </Button>
//             <Button
//               variant="outline"
//               size="icon"
//               className="h-8 w-8 border-[#1e293b] bg-[#1e293b]/50 text-slate-300 hover:bg-[#1e293b] hover:text-white"
//             >
//               <ArrowRight className="h-4 w-4" />
//             </Button>
//           </div>
//         </div>
//       </div>
//     </div>
//   )
// }

// function ArrowDown(props) {
//   return (
//     <svg
//       {...props}
//       xmlns="http://www.w3.org/2000/svg"
//       width="24"
//       height="24"
//       viewBox="0 0 24 24"
//       fill="none"
//       stroke="currentColor"
//       strokeWidth="2"
//       strokeLinecap="round"
//       strokeLinejoin="round"
//     >
//       <path d="M12 5v14" />
//       <path d="m19 12-7 7-7-7" />
//     </svg>
//   )
// }

// function ArrowUp(props) {
//   return (
//     <svg
//       {...props}
//       xmlns="http://www.w3.org/2000/svg"
//       width="24"
//       height="24"
//       viewBox="0 0 24 24"
//       fill="none"
//       stroke="currentColor"
//       strokeWidth="2"
//       strokeLinecap="round"
//       strokeLinejoin="round"
//     >
//       <path d="m12 19-7-7 7-7" />
//       <path d="m19 12-7 7-7-7" />
//     </svg>
//   )
// }
